enum TipoRegimen
{
    AllInclusive,
    MediaPension
};
